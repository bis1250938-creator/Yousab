export function isEligibleOwnerAccount(user) {
  return Boolean(user
    && user.disabled !== true
    && user.emailVerified === true
    && user.providerData?.some((provider) => provider.providerId === 'google.com' && typeof provider.uid === 'string' && provider.uid.length > 0));
}

export function addOwnerClaim(existingClaims = {}) {
  return { ...existingClaims, owner: true };
}

export function removeOwnerClaim(existingClaims = {}) {
  const { owner, ...otherClaims } = existingClaims;
  return Object.keys(otherClaims).length ? otherClaims : null;
}
