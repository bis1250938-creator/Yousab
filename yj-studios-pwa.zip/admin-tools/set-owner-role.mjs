import { applicationDefault, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { addOwnerClaim, isEligibleOwnerAccount, removeOwnerClaim } from './owner-role.mjs';

const projectId = process.env.FIREBASE_PROJECT_ID || 'yj-studio-50df5';
const [action, uid, confirmation] = process.argv.slice(2);

if (!['grant', 'revoke'].includes(action) || !uid || confirmation !== uid || uid.length > 128) {
  console.error('Usage: node set-owner-role.mjs <grant|revoke> <FIREBASE_UID> <CONFIRM_SAME_UID>');
  process.exitCode = 2;
} else {
  try {
    initializeApp({ credential: applicationDefault(), projectId });
    const auth = getAuth();
    const user = await auth.getUser(uid);

    if (action === 'grant' && !isEligibleOwnerAccount(user)) {
      throw new Error('Grant denied: this UID must be enabled, email-verified, and linked to a Google provider.');
    }

    const updatedClaims = action === 'grant'
      ? addOwnerClaim(user.customClaims)
      : removeOwnerClaim(user.customClaims);
    await auth.setCustomUserClaims(uid, updatedClaims);
    if (action === 'revoke') await auth.revokeRefreshTokens(uid);
    console.log(`Owner claim ${action === 'grant' ? 'granted to' : 'removed from'} Firebase UID ${uid} in ${projectId}.`);
    console.log('The user must sign out and sign in again to receive the updated owner claim.');
  } catch (error) {
    console.error(`Could not ${action} owner access: ${error?.message || 'Firebase Admin SDK request failed.'}`);
    process.exitCode = 1;
  }
}
