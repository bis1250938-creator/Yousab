import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { AUTH_INTENT_KEY, canUseOwnerDashboard, consumeAuthIntent, getAuthenticatedDestination, googleAuthErrorMessage, normalizeAuthIntent, resolveGoogleAuthResult, saveAuthIntent, verifyOwnerSession } from '../auth-flow.mjs';
import { addOwnerClaim, isEligibleOwnerAccount, removeOwnerClaim } from '../admin-tools/owner-role.mjs';

const auth = { currentUser: null };
const ownerToken = { claims: { owner: true, email_verified: true, firebase: { sign_in_provider: 'google.com' } } };

function googleUser(overrides = {}) {
  return {
    uid: 'firebase-uid-1',
    email: 'yousabwassim2005@gmail.com',
    emailVerified: true,
    displayName: 'YJ Owner',
    providerData: [{ providerId: 'google.com', uid: 'google-sub-123' }],
    ...overrides
  };
}

function authApi({ isNewUser = false, info = true } = {}) {
  const calls = { deleted: [], signedOut: 0 };
  return {
    calls,
    getAdditionalUserInfo: () => info ? { isNewUser } : null,
    deleteUser: async (user) => { calls.deleted.push(user.uid); },
    signOut: async () => { calls.signedOut++; }
  };
}

test('registered Google owner signs in without creating a second account', async () => {
  const user = googleUser();
  const api = authApi({ isNewUser: false });
  const result = await resolveGoogleAuthResult({ result: { user }, intent: 'signin', auth, api });
  assert.equal(result.status, 'authenticated');
  assert.equal(result.googleSub, 'google-sub-123');
  assert.deepEqual(api.calls.deleted, []);
  assert.equal(api.calls.signedOut, 0);
});

test('first-time Google owner can register and receives the normal user session', async () => {
  const user = googleUser();
  const result = await resolveGoogleAuthResult({ result: { user }, intent: 'signup', auth, api: authApi({ isNewUser: true }) });
  assert.equal(result.status, 'authenticated');
  assert.equal(result.user, user);
  assert.equal(result.intent, 'signup');
});

test('unknown Google identity attempting sign-in is deleted and signed out', async () => {
  const user = googleUser();
  const api = authApi({ isNewUser: true });
  const result = await resolveGoogleAuthResult({ result: { user }, intent: 'signin', auth, api });
  assert.equal(result.status, 'not-registered');
  assert.deepEqual(api.calls.deleted, [user.uid]);
  assert.equal(api.calls.signedOut, 1);
});

test('registered Google identity attempting sign-up is signed out without duplication', async () => {
  const user = googleUser();
  const api = authApi({ isNewUser: false });
  const result = await resolveGoogleAuthResult({ result: { user }, intent: 'signup', auth, api });
  assert.equal(result.status, 'already-registered');
  assert.deepEqual(api.calls.deleted, []);
  assert.equal(api.calls.signedOut, 1);
});

test('the same provider identity can sign up once and sign in later with the same Firebase UID', async () => {
  const firstUser = googleUser();
  const registered = await resolveGoogleAuthResult({ result: { user: firstUser }, intent: 'signup', auth, api: authApi({ isNewUser: true }) });
  const returningUser = googleUser();
  const returning = await resolveGoogleAuthResult({ result: { user: returningUser }, intent: 'signin', auth, api: authApi({ isNewUser: false }) });
  assert.equal(registered.googleSub, returning.googleSub);
  assert.equal(registered.user.uid, returning.user.uid);
  assert.equal(returning.status, 'authenticated');
});

test('signup intent survives a redirect round trip and is consumed once', async () => {
  const values = new Map();
  const storage = { setItem: (key, value) => values.set(key, value), getItem: (key) => values.get(key) ?? null, removeItem: (key) => values.delete(key) };
  assert.equal(saveAuthIntent(storage, 'signup'), true);
  assert.equal(storage.getItem(AUTH_INTENT_KEY), 'signup');
  const returnedIntent = consumeAuthIntent(storage);
  assert.equal(returnedIntent, 'signup');
  assert.equal(consumeAuthIntent(storage), null);
  const result = await resolveGoogleAuthResult({ result: { user: googleUser() }, intent: returnedIntent, auth, api: authApi({ isNewUser: true }) });
  assert.equal(result.status, 'authenticated');
  assert.equal(result.intent, 'signup');
});

test('tampered or invalid intent fails closed to sign-in', async () => {
  assert.equal(normalizeAuthIntent('redirect=https://attacker.invalid'), 'signin');
  const api = authApi({ isNewUser: true });
  const result = await resolveGoogleAuthResult({ result: { user: googleUser() }, intent: 'unexpected', auth, api });
  assert.equal(result.status, 'not-registered');
  assert.deepEqual(api.calls.deleted, ['firebase-uid-1']);
});

test('invalid OAuth result is rejected, while a failure to delete a new profile is reported', async () => {
  const api = authApi({ isNewUser: true, info: false });
  const missing = await resolveGoogleAuthResult({ result: { user: googleUser() }, intent: 'signin', auth, api });
  assert.equal(missing.status, 'invalid-credential');
  assert.equal(api.calls.signedOut, 1);

  const deleteFailureApi = { ...authApi({ isNewUser: true }), deleteUser: async () => { throw new Error('offline'); } };
  const cleanupFailure = await resolveGoogleAuthResult({ result: { user: googleUser() }, intent: 'signin', auth, api: deleteFailureApi });
  assert.equal(cleanupFailure.status, 'cleanup-failed');
  assert.equal(deleteFailureApi.calls.signedOut, 1);
});

test('only a Google session with the trusted owner claim can access the dashboard', () => {
  assert.equal(canUseOwnerDashboard(googleUser(), ownerToken), true);
  assert.equal(canUseOwnerDashboard(googleUser({ email: 'different@example.com' }), ownerToken), true);
  assert.equal(canUseOwnerDashboard(googleUser(), { claims: { email_verified: true, firebase: { sign_in_provider: 'google.com' } } }), false);
  assert.equal(canUseOwnerDashboard(googleUser(), { claims: { owner: true, email_verified: true, firebase: { sign_in_provider: 'password' } } }), false);
  assert.equal(canUseOwnerDashboard(googleUser({ providerData: [] }), ownerToken), false);
  assert.equal(canUseOwnerDashboard(null, ownerToken), false);
});

test('shared role routing sends only the trusted owner claim to the private dashboard', () => {
  assert.equal(getAuthenticatedDestination(googleUser(), ownerToken), 'dashboard.html');
  assert.equal(getAuthenticatedDestination(googleUser(), { claims: { email_verified: true, firebase: { sign_in_provider: 'google.com' } } }), 'account.html');
  assert.equal(getAuthenticatedDestination(googleUser(), { claims: { owner: true, email_verified: true, firebase: { sign_in_provider: 'password' } } }), 'account.html');
});

test('owner session verification forces a token refresh and rejects expired or revoked sessions', async () => {
  const calls = [];
  const verified = await verifyOwnerSession(googleUser(), async (user, forceRefresh) => {
    calls.push([user.uid, forceRefresh]);
    return ownerToken;
  });
  assert.equal(verified.authorized, true);
  assert.deepEqual(calls, [['firebase-uid-1', true]]);
  await assert.rejects(
    verifyOwnerSession(googleUser(), async () => { throw Object.assign(new Error('refresh token expired'), { code: 'auth/user-token-expired' }); }),
    /refresh token expired/
  );
});

test('trusted admin role assignment validates the Google UID and preserves other claims', () => {
  assert.equal(isEligibleOwnerAccount(googleUser()), true);
  assert.equal(isEligibleOwnerAccount(googleUser({ emailVerified: false })), false);
  assert.equal(isEligibleOwnerAccount(googleUser({ providerData: [] })), false);
  assert.equal(isEligibleOwnerAccount(googleUser({ disabled: true })), false);
  assert.deepEqual(addOwnerClaim({ billing: 'active' }), { billing: 'active', owner: true });
  assert.deepEqual(removeOwnerClaim({ owner: true, billing: 'active' }), { billing: 'active' });
  assert.equal(removeOwnerClaim({ owner: true }), null);
});

test('Admin SDK grant and revoke are explicit UID-only operations', async () => {
  const script = await readFile(new URL('../admin-tools/set-owner-role.mjs', import.meta.url), 'utf8');
  assert.match(script, /auth\.getUser\(uid\)/);
  assert.match(script, /auth\.setCustomUserClaims\(uid, updatedClaims\)/);
  assert.match(script, /auth\.revokeRefreshTokens\(uid\)/);
  assert.match(script, /confirmation !== uid/);
  assert.doesNotMatch(script, /getUserByEmail|email ===|email ==/);
});

test('shared auth routes owners and regular accounts through Firebase sessions', async () => {
  const authPage = await readFile(new URL('../auth.html', import.meta.url), 'utf8');
  const account = await readFile(new URL('../account.html', import.meta.url), 'utf8');
  const dashboard = await readFile(new URL('../dashboard.html', import.meta.url), 'utf8');
  const publicSite = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  const serviceWorker = await readFile(new URL('../sw.js', import.meta.url), 'utf8');
  const firestoreRules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8');
  const storageRules = await readFile(new URL('../storage.rules', import.meta.url), 'utf8');
  assert.match(authPage, /Sign in with Google/);
  assert.match(authPage, /Sign up with Google/);
  assert.match(authPage, /indexedDBLocalPersistence/);
  assert.match(authPage, /getAuthenticatedDestination\(user, tokenResult\)/);
  assert.match(authPage, /resolveGoogleAuthResult/);
  assert.match(authPage, /signInWithRedirect/);
  assert.match(authPage, /signInWithPopup/);
  assert.match(authPage, /prompt: 'select_account'/);
  assert.match(authPage, /onAuthStateChanged/);
  assert.doesNotMatch(authPage, /setCustomUserClaims|localStorage/);
  assert.match(account, /onAuthStateChanged/);
  assert.match(account, /getIdTokenResult\(user, true\)/);
  assert.match(account, /signOut\(auth\)/);
  assert.match(account, /pageshow/);
  assert.doesNotMatch(account, /localStorage/);
  assert.match(account, /location\.replace\('\.\/auth\.html\?mode=signin'\)/);
  assert.match(dashboard, /onAuthStateChanged\(auth/);
  assert.match(dashboard, /verifyOwnerSession\(user, getIdTokenResult\)/);
  assert.match(dashboard, /location\.replace\('\.\/account\.html'\)/);
  assert.doesNotMatch(dashboard, /signInWithPopup|GoogleAuthProvider|Create.*account/);
  assert.match(publicSite, /href="auth\.html">Sign in \/ create account/);
  assert.match(publicSite, /href="auth\.html">My account/);
  assert.match(dashboard, /onAuthStateChanged\(auth/);
  assert.match(dashboard, /signOut\(auth\)/);
  assert.match(dashboard, /'sidebar-logout', 'top-logout', 'mobile-logout'/);
  assert.match(firestoreRules, /function isOwner\(\)/);
  assert.match(firestoreRules, /request\.auth\.token\.owner == true/);
  assert.match(firestoreRules, /request\.auth\.token\.firebase\.sign_in_provider == 'google\.com'/);
  assert.doesNotMatch(firestoreRules, /request\.auth\.token\.email ==/);
  assert.match(storageRules, /function isOwner\(\)/);
  assert.match(storageRules, /request\.auth\.token\.owner == true/);
  assert.match(storageRules, /ownerUid == request\.auth\.uid/);
  assert.doesNotMatch(storageRules, /request\.auth\.token\.email ==/);
  assert.match(dashboard, /indexedDBLocalPersistence/);
  assert.match(dashboard, /await signOut\(auth\)/);
  assert.match(dashboard, /pageshow/);
  assert.doesNotMatch(dashboard, /setCustomUserClaims/);
  assert.match(serviceWorker, /'\.\/auth\.html'/);
  assert.match(serviceWorker, /'\.\/account\.html'/);
});

test('OAuth cancellation, invalid state, and network failures show actionable messages', () => {
  assert.match(googleAuthErrorMessage({ code: 'auth/popup-closed-by-user' }, { hostname: 'yjstudio.com' }), /closed/);
  assert.match(googleAuthErrorMessage({ code: 'auth/invalid-state' }, { hostname: 'yjstudio.com' }), /validate this redirect/);
  assert.match(googleAuthErrorMessage({ code: 'auth/network-request-failed' }, { hostname: 'yjstudio.com' }), /internet connection/);
  assert.match(googleAuthErrorMessage({ code: 'auth/unsupported-persistence-type' }, { hostname: 'yjstudio.com' }), /IndexedDB/);
  assert.match(googleAuthErrorMessage({ code: 'auth/unauthorized-domain' }, { hostname: 'preview.example' }), /preview\.example/);
});
