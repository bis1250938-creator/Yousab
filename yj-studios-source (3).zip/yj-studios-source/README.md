# YJ Studios website

Editable static website source. There is no build step. The package includes an owner dashboard with Firebase Google sign-in.

## Files

- `index.html` — responsive studio site, portfolio upload gallery, audio visualizer, and session request form.
- `dashboard.html` — owner sign-in, portfolio management, project counts, service rates, activity, and the private booking inbox.
- `auth-flow.mjs` — validated Google sign-in/sign-up intent handling shared by the dashboard and its Node tests.
- `firebase-config.js` — Firebase Web app configuration used for Google sign-in.
- `firebase-client.js` / `site-cloud.js` — Firebase initialization, public portfolio reads, and booking request writes.
- `firestore.rules` / `storage.rules` — owner-only dashboard data and uploads, with published portfolio media readable by visitors.
- `firestore.indexes.json` / `firebase.json` / `storage-cors.json` — Firestore query index, Firebase rule deployment, and audio visualizer CORS setup.
- `site.webmanifest` — app name, colors, and home-screen icons.
- `dashboard.webmanifest` — separate phone install entry that opens directly to the owner dashboard.
- `sw.js` — offline cache for the website shell.
- `tests/auth-flow.test.mjs` — mocked Google account-flow tests (`node --test tests/auth-flow.test.mjs`).
- `admin-tools/` — privileged Firebase Admin SDK script to grant or revoke the owner claim by Firebase UID. Keep its admin credentials out of the website.
- `yj-studios-logo.jpg` — supplied studio logo.
- `icons/` — Android and iPhone home-screen icons.
- `INSTALL-ON-PHONE.txt` — publishing and phone-install steps.

## Edit and preview in VS Code

1. Extract `yj-studios-pwa.zip`.
2. In VS Code, choose **File → Open Folder…** and open the extracted folder.
3. Edit `index.html` for the page, styling, and interactive behavior. Edit `site.webmanifest` for the app name and colors.
4. For local PWA and offline behavior, serve the folder from `localhost` with a static server such as VS Code Live Server. Opening `index.html` as a `file://` URL does not enable the service worker.

To keep the site or owner dashboard on a phone, publish the website files at an HTTPS address and follow `INSTALL-ON-PHONE.txt`. Do not publish `admin-tools/`. Open `dashboard.html` on the phone to add a separate YJ Owner icon. The dashboard still requires internet access for Google sign-in and live booking data.

## Portfolio and booking data

Sign in to `dashboard.html` with the Google account that has been assigned the owner role to add, publish, review, or remove portfolio projects. New uploads are sent to Firebase Cloud Storage and published in the gallery across devices. Older projects saved in this browser remain there until you choose **Publish** beside them. If cloud upload is unavailable, new files are saved locally and the dashboard explains how to publish them later.

Published media is public so visitors can play or view it; only the owner account can upload or delete files. Cloud Storage requires the Firebase Blaze billing plan. Downloads and stored files may incur charges, so set a budget alert and publish media intended for the public site only.

When Firestore is enabled and `firestore.rules` are published, the public booking form sends inquiries to a private owner-only inbox. The dashboard shows new requests live and lets the owner update their status or delete them. A request is not a confirmed session. If Firestore is not configured or sending fails, the visitor can still copy and share the request.

## Owner sign-in and role setup

The dashboard opens on **Sign in with Google**. The existing owner Firebase account is reused; there is no requirement to register again. The optional **Set up with Google** action only creates a Firebase Auth identity. It never grants the owner role.

Owner access is represented by the Firebase Auth custom claim `owner: true`, assigned only by the trusted Admin SDK tool in `admin-tools/`. The script targets an explicit Firebase UID, requires that the account is enabled, email-verified, and linked to Google, preserves unrelated custom claims, and requires the UID to be typed twice. The application does not grant a role from a client-provided email, Google sign-in alone, or local storage. Firestore and Storage Security Rules independently require the signed Firebase ID token to contain the owner claim and to represent a verified Google session. Firebase documents that custom claims must be assigned from a privileged Admin SDK environment and can be enforced in Security Rules: [custom claims](https://firebase.google.com/docs/auth/admin/custom-claims), [Security Rules and Auth](https://firebase.google.com/docs/rules/rules-and-auth).

This is a static Firebase client application with no custom HTTP server or application user table. Firebase Auth is the account store; its Firebase UID maps the linked Google identity. `getAdditionalUserInfo(...).isNewUser` keeps the sign-in and sign-up actions distinct. Sign-in to a previously unseen identity is rejected and its just-created Firebase Auth record is removed. Sign-up can create an unprivileged Firebase identity, which cannot read owner data or open the dashboard until an administrator grants the claim. Firebase Auth provisions first-time federated identities before the app receives the result, so a failed cleanup on a sign-in attempt must be removed from **Authentication → Users**.

Google is the only owner login provider present in this project; there is no existing email/password authentication route to preserve or migrate.

The dashboard refreshes and verifies the Firebase ID token's owner claim before revealing private data. Firebase SDK local persistence is explicitly stored in IndexedDB, not copied into application localStorage; it survives refreshes on that browser and origin. Each browser/device signs in with Google separately. Firebase-managed ID tokens are checked by Firestore and Storage on each request. This site has no custom backend endpoints or cookie session to secure; if one is added later, it must verify the Firebase ID token with the Admin SDK and authorize the `owner` claim. [Firebase Auth persistence](https://firebase.google.com/docs/auth/web/auth-state-persistence), [Admin SDK token verification](https://firebase.google.com/docs/auth/admin/verify-id-tokens).

### One-time owner setup

1. In Firebase Console, enable Google under **Authentication → Sign-in method** and add `yjstudio.com` under **Authentication → Settings → Authorized domains**. The Firebase Web app is `yj-studio-50df5` with `authDomain` `yj-studio-50df5.firebaseapp.com`; the OAuth handler is `https://yj-studio-50df5.firebaseapp.com/__/auth/handler`. For local Live Server, use `http://localhost:5500` and authorize `localhost`. Never use `file://` for sign-in.
2. In **Authentication → Users**, find the existing owner account linked to Google and copy its Firebase UID. If that Auth account does not exist yet, publish the site and use **Set up with Google** once; this creates only an unprivileged account. Verify the UID corresponds to the intended owner before granting a role.
3. Install and sign in to the Firebase CLI (`npm install -g firebase-tools`, then `firebase login`). From `outputs/`, deploy the rules with `firebase deploy --only firestore,storage --project yj-studio-50df5`. This removes the old email-based authorization check; the dashboard remains blocked until the next step assigns the owner claim.
4. In a trusted admin terminal, install the isolated tool dependency and authenticate with Google Cloud Application Default Credentials using an account permitted to administer this Firebase project:

   ```powershell
   cd outputs/admin-tools
   npm install
   gcloud auth application-default login
   node set-owner-role.mjs grant FIREBASE_UID FIREBASE_UID
   ```

   Replace both `FIREBASE_UID` values with the same UID copied from Firebase Console. The tool does not accept an email as the grant target. Keep ADC credentials and any service-account files outside the published website and source ZIP.
5. The owner signs out, then signs in on `dashboard.html`. The dashboard force-refreshes the ID token and checks the new claim. Existing owner Auth data is preserved; there is no database migration.
6. To revoke owner access, run `node set-owner-role.mjs revoke FIREBASE_UID FIREBASE_UID` from `outputs/admin-tools`, then sign out the owner. The role claim is removed, unrelated claims are preserved, and refresh tokens are revoked. Firebase ID tokens already issued can remain usable until they expire; the app force-refreshes before opening the dashboard.

The client-side dashboard gate is for navigation and feedback; the rules are the actual data security boundary. Storage paths remain scoped to the Firebase UID. No OAuth client secret or Admin SDK key belongs in `firebase-config.js` or any published file.

Publish `dashboard.html`, `auth-flow.mjs`, the Firebase web config/client files, site files, service worker, manifests, icons, and logo at the site root. Do not publish `admin-tools/` with credentials. The Firebase Web `apiKey` and app ID are public client configuration. Firestore has a no-cost daily quota; usage above that quota requires billing. See [Firebase pricing](https://firebase.google.com/docs/firestore/pricing).

Run the mocked auth/role tests with `node --test tests/auth-flow.test.mjs`. They cover distinct sign-in/sign-up results, redirect intent, trusted role-claim checks, admin tool eligibility, logout wiring, owner-only rules, and error messages. They do not contact Google, connect to Firebase, or emulate/deploy Security Rules. This repository has no web build, lint, or type-check configuration. Google opens its own sign-in page; never enter a Google password into this website or share service-account credentials.
